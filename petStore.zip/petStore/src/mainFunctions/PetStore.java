package mainFunctions;



import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pom.PomPetstore;
public class PetStore 
{
	PomPetstore p= new PomPetstore();
	WebDriver driver;
	@BeforeTest
	public void beforeTest() throws Exception  
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Browser Extention\\chromedriver.exe");
		driver =new ChromeDriver();
		Thread.sleep(2000);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		p.url(driver);
		Thread.sleep(2000);
		p.enterusername(driver, "Admin");
		Thread.sleep(2000);
		p.enterpassword(driver, "Admin123");
		Thread.sleep(2000);
		p.login(driver);		 
	}

	@Test(priority = 1, description = "Checking HomePage")
	public void Home() throws Exception 
	{

		driver.findElement(By.cssSelector("#QuickLinks > a:nth-child(1) > img")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/a/img")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/a[1]/img")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[1]/a")).click();

		//Function ScreenShot of Home

		File screenshotFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("./Home.jpeg"));

	}


	@Test(priority = 2, description = "Creating Account Details")
	public void MyAccount() throws Exception
	{
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/a[3]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='password']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Admin123");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='repeatedPassword']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='repeatedPassword']")).sendKeys("Admin123");
		Thread.sleep(2000);
		driver.findElement(By.name("account.firstName")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.firstName")).sendKeys("Pradeep");
		Thread.sleep(2000);
		driver.findElement(By.name("account.lastName")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.lastName")).sendKeys("C");
		Thread.sleep(2000);
		driver.findElement(By.name("account.email")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.email")).sendKeys("pradeep123@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.name("account.phone")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.phone")).sendKeys("7687957587");
		Thread.sleep(2000);
		driver.findElement(By.name("account.address1")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.address1")).sendKeys("123");
		Thread.sleep(2000);
		driver.findElement(By.name("account.address2")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.address2")).sendKeys("Street");
		Thread.sleep(2000);
		driver.findElement(By.name("account.city")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.city")).sendKeys("Coimbatore");
		Thread.sleep(2000);
		driver.findElement(By.name("account.state")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.state")).sendKeys("Tamilnadu");
		Thread.sleep(2000);
		driver.findElement(By.name("account.zip")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.zip")).sendKeys("645363");
		Thread.sleep(2000);
		driver.findElement(By.name("account.country")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.country")).sendKeys("India");
		Thread.sleep(2000);
		Select s1=new Select(driver.findElement(By.xpath("/html/body/div[2]/div/form/table[3]/tbody/tr[1]/td[2]/select")));
		s1.selectByVisibleText("english");
		Thread.sleep(2000);
		Select s2=new Select(driver.findElement(By.xpath("/html/body/div[2]/div/form/table[3]/tbody/tr[2]/td[2]/select")));
		s2.selectByIndex(0);
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div/form/table[3]/tbody/tr[3]/td[2]/input")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/table[3]/tbody/tr[4]/td[2]/input")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='editAccount']")).click();
		Thread.sleep(2000);

		//Function ScreenShot of MyAccount

		File screenshotFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("./MyAccount.jpeg"));
	}
	@Test(priority = 3, description = "Checking Cart")
	public void Cart() throws Exception 
	{
		driver.findElement(By.xpath("//img[@src='../images/sm_dogs.gif']")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("K9-BD-01")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[5]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"Cart\"]/form/table/tbody/tr[2]/td[5]/input")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"Cart\"]/form/table/tbody/tr[3]/td[1]/input")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"BackLink\"]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"SidebarContent\"]/a[4]/img")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[5]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/a[1]/img")).click();

		//Function ScreenShot of Cart

		File screenshotFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("./Cart.jpeg"));
	}

	@Test(priority = 4, description = "Checking Search")
	public void Search() throws Exception 
	{
		driver.findElement(By.xpath("//*[@id=\"SearchContent\"]/form/input[1]")).sendKeys("koi");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"SearchContent\"]/form/input[2]")).sendKeys(Keys.ENTER);

		//Function ScreenShot of Search

		File screenshotFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("./Search.jpeg"));

		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"SearchContent\"]/form/input[1]")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"SearchContent\"]/form/input[1]")).sendKeys("Birds");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"SearchContent\"]/form/input[2]")).sendKeys(Keys.ENTER);



	}
	@Test(priority = 5, description = "Info")
	public void info() throws Exception 
	{
		driver.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[4]")).click();
		Thread.sleep(000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(2000);
		js.executeScript("window.scrollTo(0,-document.body.scrollHeight)");

		//Function ScreenShot of Info

		File screenshotFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("./Info.jpeg"));

		driver.navigate().back();	  
	}
	@Test(priority = 7, description = "Stock not Available But Order Successfull")
	public void Defect1() throws Exception 
	{
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[4]/a[1]/img[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[5]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@value='Update Cart']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div/form/input")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/a")).click();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(2000);


		//  Stock not available but OrderSuccuss
		//function Screenshot of ClickImage

		File screenshotFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("./Defect1.jpeg"));
	}

	@Test(priority = 8, description = "No increase and decrease option and if we click remove totally removed from Cart  ")
	public void Defect2() throws Exception 
	{
		driver.findElement(By.xpath("/html/body/div[1]/div[4]/a[3]/img")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[5]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td[5]/input")).sendKeys("2");
		Thread.sleep(2000);
		//No increase decrease option and if we click remove totally removed from cart
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td[8]/a")).click();
		Thread.sleep(2000);

		//Function ScreenShot of Defect2

		File screenshotFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("./Defect2.jpeg"));


	}
	@Test(priority = 6, description = "Checking My orders")
	public void MyOrder() throws Exception 
	{
		driver.findElement(By.xpath("//a[normalize-space()='My Account']")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("My Orders")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[normalize-space()='31216']")).click();
		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(2000);

		//Function ScreenShot of MyOrders
		File screenshotFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("./MyOrders.jpeg"));
	}
	@Test(priority = 9, description = "Invalid Data Enter")
	public void Defect3() throws Exception 
	{
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/a[3]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='password']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Admin123");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='repeatedPassword']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='repeatedPassword']")).sendKeys("Admin123");
		Thread.sleep(2000);
		driver.findElement(By.name("account.firstName")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.firstName")).sendKeys("123");
		Thread.sleep(2000);
		driver.findElement(By.name("account.lastName")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.lastName")).sendKeys("3");
		Thread.sleep(2000);
		driver.findElement(By.name("account.email")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.email")).sendKeys("pr3@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.name("account.phone")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.phone")).sendKeys("7687957fgh7");
		Thread.sleep(2000);
		driver.findElement(By.name("account.address1")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.address1")).sendKeys("drg");
		Thread.sleep(2000);
		driver.findElement(By.name("account.address2")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.address2")).sendKeys("34fgeg");
		Thread.sleep(2000);
		driver.findElement(By.name("account.city")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.city")).sendKeys("34r35g");
		Thread.sleep(2000);
		driver.findElement(By.name("account.state")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.state")).sendKeys("354ygdf");
		Thread.sleep(2000);
		driver.findElement(By.name("account.zip")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.zip")).sendKeys("6fghy45");
		Thread.sleep(2000);
		driver.findElement(By.name("account.country")).clear();
		Thread.sleep(2000);
		driver.findElement(By.name("account.country")).sendKeys("346et");
		Thread.sleep(2000);
		Select s1=new Select(driver.findElement(By.xpath("/html/body/div[2]/div/form/table[3]/tbody/tr[1]/td[2]/select")));
		s1.selectByVisibleText("english");
		Thread.sleep(2000);
		Select s2=new Select(driver.findElement(By.xpath("/html/body/div[2]/div/form/table[3]/tbody/tr[2]/td[2]/select")));
		s2.selectByIndex(0);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='editAccount']")).click();
		Thread.sleep(2000);

		//Function ScreenShot of Defect3
		File screenshotFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("./Defect3.jpeg"));

	}
	@AfterTest
	public void afterTest() 
	{
		p.closebrowser(driver);
	}

}