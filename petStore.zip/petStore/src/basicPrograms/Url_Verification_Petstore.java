package basicPrograms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Url_Verification_Petstore 
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Browser Extention\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
		Thread.sleep(1000);
		String AccepctedTitle="JPetStore Demo";
		String ActualTitle=driver.getTitle();
		if(ActualTitle.equals(AccepctedTitle))
		{
			System.out.println("Title Verification Passed");
		}
		else
		{
			System.out.println("Title Verification Failed");
		}
		Thread.sleep(2000);
		
		//URL Verification
		String Accepctedurl="https://petstore.octoperf.com/actions/Account.action?signonForm=";
		String Actualurl=driver.getCurrentUrl();
		if(Actualurl.equals(Accepctedurl))
		{
			System.out.println("URL Verification Passed");	
		}
		else
		{
			System.out.println("URL Verification Failed");
		}
		
		driver.close();
	}	

}
