package basicPrograms;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Logout 
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Browser Extention\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
		Thread.sleep(1000);
		
		String usn=JOptionPane.showInputDialog("Enter User Name");
		driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[1]")).sendKeys(usn);
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]")).clear();
		String pwd=JOptionPane.showInputDialog("Enter User Password");
		driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]")).sendKeys(pwd);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/input")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();
		Thread.sleep(1000);
		driver.close();
	}

}
