package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Registation_Petstore 
{

	public static void main(String[] args) throws Exception 
	{
		//open browser
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Browser Extention\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		//open URL
		driver.get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
		Thread.sleep(1000);
		//Registration Details
		driver.findElement(By.linkText("Register Now!")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html/body/div[2]/div/form/table[1]/tbody/tr[1]/td[2]/input")).sendKeys("Admin");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Admin123");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@name='repeatedPassword']")).sendKeys("Admin123");
		Thread.sleep(1000);
		driver.findElement(By.name("account.firstName")).sendKeys("Pradeep");
		Thread.sleep(1000);
		driver.findElement(By.name("account.lastName")).sendKeys("C");
		Thread.sleep(1000);
		driver.findElement(By.name("account.email")).sendKeys("pradeep123@gmail.com");
		Thread.sleep(1000);
		driver.findElement(By.name("account.phone")).sendKeys("7687957587");
		Thread.sleep(1000);
		driver.findElement(By.name("account.address1")).sendKeys("123");
		Thread.sleep(1000);
		driver.findElement(By.name("account.address2")).sendKeys("Street");
		Thread.sleep(1000);
		driver.findElement(By.name("account.city")).sendKeys("Coimbatore");
		Thread.sleep(1000);
		driver.findElement(By.name("account.state")).sendKeys("Tamilnadu");
		Thread.sleep(1000);
		driver.findElement(By.name("account.zip")).sendKeys("645363");
		Thread.sleep(1000);
		driver.findElement(By.name("account.country")).sendKeys("India");
		Thread.sleep(1000);
		Select s1=new Select(driver.findElement(By.xpath("/html/body/div[2]/div/form/table[3]/tbody/tr[1]/td[2]/select")));
		s1.selectByIndex(1);
		Thread.sleep(1000);
		Select s2=new Select(driver.findElement(By.xpath("/html/body/div[2]/div/form/table[3]/tbody/tr[2]/td[2]/select")));
		s2.selectByIndex(1);
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html/body/div[2]/div/form/table[3]/tbody/tr[3]/td[2]/input")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/table[3]/tbody/tr[4]/td[2]/input")).click();
		Thread.sleep(1000);
		driver.findElement(By.name("newAccount")).click();
		Thread.sleep(1000);
		driver.close();
		
		
		
	}

}
