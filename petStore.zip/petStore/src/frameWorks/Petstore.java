package frameWorks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pom.PomPetstore;



public class Petstore {
	
	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() throws Exception 
	 {
		 System.setProperty("webdriver.chrome.driver","C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Browser Extention\\chromedriver.exe");
			driver =new ChromeDriver();
			Thread.sleep(1000);
			 driver.manage().window().maximize();
			 Thread.sleep(1000);
			  driver.manage().deleteAllCookies();
	  }
 
	 @Test
  public void f() throws Exception 
	 {
		 PomPetstore p= new PomPetstore();
		 p.url(driver);
		 Thread.sleep(2000);
		 p.enterusername(driver, "Admin");
		 Thread.sleep(2000);
		 p.enterpassword(driver, "Admin123");
		 Thread.sleep(2000);
		 p.login(driver);
		 Thread.sleep(2000);
		 p.logout(driver);
		 
		
		 
  
	 }
 

  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
