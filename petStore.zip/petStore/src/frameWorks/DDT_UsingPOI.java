package frameWorks;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pom.PomPetstore;

public class DDT_UsingPOI 
{

	public static void main(String[] args) throws Exception 
	{
    FileInputStream file = new FileInputStream("C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Eclips Backup\\petStore\\PetStore.xlsx");
    XSSFWorkbook w = new XSSFWorkbook(file);
    XSSFSheet s = w.getSheet("DDT");
    int rowsize = s.getLastRowNum();
    System.out.println("No of Credentials: " + rowsize);
    System.setProperty("webdriver.chrome.driver", "C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Browser Extention\\chromedriver.exe");
    WebDriver driver = new ChromeDriver();

    for (int i = 1; i <= rowsize; i++) {
        // Create a new instance of POM class for each iteration
        PomPetstore p = new PomPetstore();
        String Username = s.getRow(i).getCell(0).getStringCellValue();
        String password = s.getRow(i).getCell(1).getStringCellValue();
        System.out.println(Username + "\t\t" + password);
        try {
            p.url(driver);
            Thread.sleep(2000);
            p.maximizeBrowser(driver);
            Thread.sleep(2000);
            p.enterusername(driver, Username);
            p.enterpassword(driver, password);
            Thread.sleep(2000);
            p.login(driver);
            Thread.sleep(2000);

            // Add validation here based on your application's behavior for successful login
            boolean isValid = p.equals(driver);
            if (isValid) {
                System.out.println("Valid Credentials");
                s.getRow(i).createCell(2).setCellValue("Valid Credentials");
            } else {
                System.out.println("Invalid Credentials");
                s.getRow(i).createCell(2).setCellValue("Invalid Credentials");
            }

            p.logout(driver);
        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
            System.out.println("Invalid Credentials");
            s.getRow(i).createCell(2).setCellValue("Invalid Credentials");
        }
    }

    FileOutputStream out = new FileOutputStream("C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Eclips Backup\\petStore\\PetStore.xlsx");
    w.write(out);
    driver.close();
}
}