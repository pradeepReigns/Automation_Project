package frameWorks;

import org.testng.annotations.Test;


import pom.PomPetstore;

import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class DDT_UsingTestNG {
	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() 
	  {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Browser Extention\\chromedriver.exe");
		 driver=new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().deleteAllCookies();
	  }
 @Test(dataProvider = "D")
 public void f(String usn, String pwd) throws Exception 
 {
	 PomPetstore p= new PomPetstore();
	 p.url(driver);
	 Thread.sleep(2000);
	 p.enterusername(driver, usn);
	 Thread.sleep(2000);
	 p.enterpassword(driver, pwd);
	 Thread.sleep(2000);
	 p.login(driver);
	 Thread.sleep(2000);
	 p.logout(driver);
	  
	  
	  
 }

 @DataProvider
 public Object[][] D() 
 {
   return new Object[][] 
   		{
     new Object[] { "Admin", "Admin123" },
   };
 }


 @AfterTest
 public void afterTest() 
 {
	  driver.close();
 }
}
