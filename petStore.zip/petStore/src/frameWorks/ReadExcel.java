package frameWorks;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;


public class ReadExcel 
{

	public void ReadExcel(WebDriver driver) throws Exception
	{
		FileInputStream file=new FileInputStream("C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Eclips Backup\\petStore\\PetStore.xlsx");
		XSSFWorkbook wb=new XSSFWorkbook(file);
		XSSFSheet s1=wb.getSheet("KDT");

		int rowSize=s1.getLastRowNum();
		System.out.println("No of Keywords: "+rowSize);

		OperationalClass O=new OperationalClass();

		for(int i=1;i<=rowSize;i++)
		{
			String key=s1.getRow(i).getCell(0).getStringCellValue();
			System.out.println(key);
			if (key.equals("OpenUrl"))
			{
				O.url(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("MaximizeBrowser"))
			{
				O.maximizeBrowser(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("EnterUsername"))
			{
				O.enterusername(driver,"Admin");
				Thread.sleep(4000);
			}
			
			else if(key.equals("EnterUserPassword"))
			{
				O.enterpassword(driver,"Admin123");
				Thread.sleep(2000);
			}
			else if(key.equals("ClickOnLoginButton"))
			{
				O.login(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("ClickOnLogoutButton"))
			{
				O.logout(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("CloseBrowser"))
			{
			O.CloseBrowser(driver);
			Thread.sleep(2000);
			}


		}

	}
}
