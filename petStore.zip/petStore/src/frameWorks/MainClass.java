package frameWorks;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;


public class MainClass 
{

	public static void main(String[] args) throws Exception 
	{
		//Launch Browser
				System.setProperty("webdriver.chrome.driver","C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Browser Extention\\chromedriver.exe");
				WebDriver driver=new ChromeDriver();
				Thread.sleep(2000);
				
				//create object of ReadExcelClass
				ReadExcel r1= new ReadExcel();
				r1.ReadExcel(driver);
		
	}

}
