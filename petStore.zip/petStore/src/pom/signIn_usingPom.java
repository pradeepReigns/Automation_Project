package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class signIn_usingPom 
{
	
	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\elcot\\Desktop\\Software Testing\\Automation Testing\\Browser Extention\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		
		PomPetstore p= new PomPetstore();
		p.url(driver);
		Thread.sleep(2000);
		p.maximizeBrowser(driver);
		Thread.sleep(2000);
		p.delCookies(driver);
		Thread.sleep(2000);
		p.enterusername(driver, "Admin");
		Thread.sleep(2000);
		p.enterpassword(driver, "Admin123");
		Thread.sleep(2000);
		p.login(driver);
		Thread.sleep(2000);
		p.logout(driver);
		Thread.sleep(2000);
		p.closebrowser(driver);
	}

}
