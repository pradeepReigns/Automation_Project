package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PomPetstore 
{
			public void url(WebDriver driver)
			{
				driver.get("https://petstore.octoperf.com/actions/Account.action?signonForm=");
			}
			public void maximizeBrowser(WebDriver driver)
			{
				driver.manage().window().maximize();
			}
			public void delCookies(WebDriver driver)
			{
				driver.manage().deleteAllCookies();
			}
			public void enterusername(WebDriver driver, String usn)
			{
				driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[1]")).sendKeys(usn);
			}
		
			public void enterpassword(WebDriver driver, String pwd) throws Exception
			{
				Thread.sleep(2000);
				driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]")).clear();
				Thread.sleep(2000);
				driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]")).sendKeys(pwd);
			}
			public void login(WebDriver driver)
			{
				driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/input")).click();
			}
			public void logout(WebDriver driver)
			{
				driver.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();
			}
			public void closebrowser(WebDriver driver)
			{
				driver.close();
			}
			

}
